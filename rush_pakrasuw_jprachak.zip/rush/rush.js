function dropdown() {
    var x = document.getElementById("menu");
    if (x.className === "borderhead") {
      x.className += " responsive";
    } else {
      x.className = "borderhead";
    }
  }

  var mySong= document.getElementById("mySong");
  var icon= document.getElementById("icon");
  
  icon.onclick = function(){
    console.log("hello")
      if(mySong.paused){
          mySong.play();
          icon.src="image/pause.png";
          }
      else{
          mySong.pause();
          icon.src="image/play.png";
      }
          }

